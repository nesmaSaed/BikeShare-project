References & Resources:
Python documentation
Pandas documentation


websites:
stackoverflow.com
geeksforgeeks.org
w3schools.com


helpful courses:
HarvardX CS50P "CS50's Introduction to Programming with Python"
